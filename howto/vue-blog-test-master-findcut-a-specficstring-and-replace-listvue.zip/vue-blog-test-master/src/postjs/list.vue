
<template>
<ul>
<router-link to=apost><li><apost></apost></li></router-link>
<router-link to=bpost><li><bpost></bpost></li></router-link>
<router-link to=cpost><li><cpost></cpost></li></router-link>
<router-link to=dpost><li><dpost></dpost></li></router-link>
</ul>
</template>
