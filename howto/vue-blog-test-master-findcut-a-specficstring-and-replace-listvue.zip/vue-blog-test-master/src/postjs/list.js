
import Vue from 'vue'
import apost from '../posts/apost.vue'
Vue.component('apost', apost)
import bpost from '../posts/bpost.vue'
Vue.component('bpost', bpost)
import cpost from '../posts/cpost.vue'
Vue.component('cpost', cpost)
import dpost from '../posts/dpost.vue'
Vue.component('dpost', dpost)
export default [apost, bpost, cpost, dpost]
