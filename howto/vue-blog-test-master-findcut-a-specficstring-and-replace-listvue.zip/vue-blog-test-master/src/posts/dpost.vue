<template>
  <div class="ddd">
    <div class="title">{{title}}</div>
  </div>
</template>

<script>
  export default {
    name: 'ddd',
    data () {
      return {
        title: '这可还行'
      }
    }
  }
</script>