<template>
  <div class="ccc">
    <div class="title">{{title}}</div>
  </div>

  
</template>


<script>
  export default {
    name: 'ccc',
    data () {
      return {
        title: '可惜不是天才'
      }
    }
  }
</script>
