<template>
  <div class="aaa">
    <div class="title">{{title}}</div>
    <test></test>
  </div>
</template>

<script>
  export default {
    name: 'aaa',
    data () {
      return {
        title:'我是人'
      }
    }
  }
</script>