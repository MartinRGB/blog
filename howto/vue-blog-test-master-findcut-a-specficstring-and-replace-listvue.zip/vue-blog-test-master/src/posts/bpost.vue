<template>
  <div class="bbb">
    <div class="title">{{title}}</div>
  </div>


  
</template>
<script>
  export default {
    name: 'bbb',
    data () {
      return {
        title: '我是个大人物'
      }
    }
  }
</script>