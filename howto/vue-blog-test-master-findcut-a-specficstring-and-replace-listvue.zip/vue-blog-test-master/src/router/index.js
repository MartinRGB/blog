import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'

// Use Shell Import article component here;
import dpost from '@/posts/dpost' 
import cpost from '@/posts/cpost' 
import bpost from '@/posts/bpost' 
import apost from '@/posts/apost' 

Vue.use(Router)


export default new Router({
  routes: [
    {path: '/',name: 'Hello',component: Hello}
    // Use Shell Export article component here;
   ,{path: '/dpost',name: 'dpost',component: dpost} 
   ,{path: '/cpost',name: 'cpost',component: cpost} 
   ,{path: '/bpost',name: 'bpost',component: bpost} 
   ,{path: '/apost',name: 'apost',component: apost} 

  ]
})
