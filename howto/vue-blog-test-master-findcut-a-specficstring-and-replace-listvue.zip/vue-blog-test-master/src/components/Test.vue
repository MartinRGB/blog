<template>
  <div class="test">test</div>
</template>

<script>
export default { name: 'test'}
</script>
