
<template>
<ul>
<router-link to=*><li><*></*></li></router-link>
</ul>
</template>
