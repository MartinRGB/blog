
import Vue from 'vue'
import LICENSE README.md build config index.html list.js list.vue node_modules package-lock.json package.json src static yarn.lock from '../posts/*.vue'
Vue.component('*', *)
export default [*]
