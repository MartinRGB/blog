
import Vue from 'vue'
import apost from '../posts/apost.vue'
Vue.component('apost', apost)
import bpost from '../posts/bpost.vue'
Vue.component('bpost', bpost)
