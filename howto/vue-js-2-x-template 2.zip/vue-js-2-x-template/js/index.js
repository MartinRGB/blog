Vue.component('input-charsleft-counter', {
  template: '#input-charsleft-counter',
  props: [
    'text',
    'maxLength',
    'warningLimit',
    'invalidClass',
    'warningClass',
    'show'
  ],
  computed: {
    charsLeft: function() {
      if(this.show == null){
        return this.maxLength - this.text.length
      }
      else{
        return this.show
      }
    },
    myClass: function() {
      if (this.charsLeft < 0)
        return this.invalidClass;
      if (this.charsLeft <= this.warningLimit)
        return this.warningClass;
      return '';
    }
  }
});

let vm = new Vue({
  data() {
    return {
      story: "ASDF".repeat(120),
      words: "Hellow World"
    };
  },
  el: '#app-vue'
})